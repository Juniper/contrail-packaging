==================
The ``User`` Class
==================

.. automodule:: openstack_auth.user
   :members:
